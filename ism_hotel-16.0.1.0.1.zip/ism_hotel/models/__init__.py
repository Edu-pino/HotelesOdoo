from . import product_template
from . import hotel_amenity
from . import hotel_amenity_line
from . import hotel_room
from . import hotel_book_history
from . import hotel_book_history_line
from . import sale_order
from . import sale_order_line
from . import account_move_line
from . import account_move
# from . import hotel_reservation
# from . import hotel_reservation_line